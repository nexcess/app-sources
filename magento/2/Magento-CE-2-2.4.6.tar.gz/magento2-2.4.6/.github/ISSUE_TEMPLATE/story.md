---
name: GraphQL Story
about: User story for GraphQL project
labels: 'Project: GraphQL'

---

*As a ___ I want to ___ so that ___.*

### AC
* a
* b
### Approved Schema
* a
