<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'fu', 'ge', NULL, 'mo', 'zhu', 'nai', 'xian', 'wen', 'li', 'can', 'mie', 'jian', 'ni', 'chai', 'wan', 'xu',
  0x10 => 'nu', 'mai', 'zui', 'kan', 'ka', 'hang', NULL, NULL, 'yu', 'wei', 'zhu', NULL, NULL, 'yi', NULL, 'diao',
  0x20 => 'fu', 'bi', 'zhu', 'zi', 'shu', 'xia', 'ni', NULL, 'jiao', 'xun', 'chong', 'nou', 'rong', 'zhi', 'sang', NULL,
  0x30 => 'shan', 'yu', NULL, 'jin', NULL, 'lu', 'han', 'bie', 'yi', 'zui', 'zhan', 'yu', 'wan', 'ni', 'guan', 'jue',
  0x40 => 'beng', 'can', NULL, 'duo', 'qi', 'yao', 'kui', 'ruan', 'hou', 'xun', 'xie', NULL, 'kui', NULL, 'xie', 'bo',
  0x50 => 'ke', 'cui', 'xu', 'bai', 'ou', 'zong', NULL, 'ti', 'chu', 'chi', 'niao', 'guan', 'feng', 'xie', 'deng', 'wei',
  0x60 => 'jue', 'kui', 'zeng', 'sa', 'duo', 'ling', 'meng', NULL, 'guo', 'meng', 'long', NULL, 'ying', NULL, 'guan', 'cu',
  0x70 => 'li', 'du', NULL, 'biao', NULL, 'xi', NULL, 'de', 'de', 'xian', 'lian', NULL, 'shao', 'xie', 'shi', 'wei',
  0x80 => NULL, NULL, 'he', 'you', 'lu', 'lai', 'ying', 'sheng', 'juan', 'qi', 'jian', 'yun', NULL, 'qi', NULL, 'lin',
  0x90 => 'ji', 'mai', 'chuang', 'nian', 'bin', 'li', 'ling', 'gang', 'cheng', 'xuan', 'xian', 'hu', 'bi', 'zu', 'dai', 'dai',
  0xA0 => 'hun', 'sai', 'che', 'ti', NULL, 'nuo', 'zhi', 'liu', 'fei', 'jiao', 'guan', 'xi', 'lin', 'xuan', 'reng', 'tao',
  0xB0 => 'pi', 'xin', 'shan', 'zhi', 'wa', 'tou', 'tian', 'yi', 'xie', 'pi', 'yao', 'yao', 'nu', 'hao', 'nin', 'yin',
  0xC0 => 'fan', 'nan', 'yao', 'wan', 'yuan', 'xia', 'zhou', 'yuan', 'shi', 'mian', 'xi', 'ji', 'tao', 'fei', 'xue', 'ni',
  0xD0 => 'ci', 'mi', 'bian', NULL, 'na', 'yu', 'e', 'zhi', 'ren', 'xu', 'lue', 'hui', 'xun', 'nao', 'han', 'jia',
  0xE0 => 'dou', 'hua', 'tu', 'ping', 'cu', 'xi', 'song', 'mi', 'xin', 'wu', 'qiong', 'zhang', 'tao', 'xing', 'jiu', 'ju',
  0xF0 => 'hun', 'ti', 'man', 'yan', 'ji', 'shou', 'lei', 'wan', 'che', 'can', 'jie', 'you', 'hui', 'zha', 'su', 'ge',
];
